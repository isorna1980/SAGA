
%%%%%%%% INITIAL PARAMETERS 

load V_WIND
load Building_demand
electrolyser_thermodynamic_data

%% LEAD-ACID BATTERY SUBMODEL%%

Nominal_voltage = Simulink.Parameter
Nominal_voltage.RTWInfo.StorageClass = 'SimulinkGlobal';
Nominal_voltage=48;


SOC_INI = Simulink.Parameter
SOC_INI.RTWInfo.StorageClass = 'SimulinkGlobal';
SOC_INI=50;% state of charge

Rated_capacity = Simulink.Parameter
Rated_capacity.RTWInfo.StorageClass = 'SimulinkGlobal';
Rated_capacity=367; %Ah at C10


%% LITHIUM-ION BATTERY SUBMODEL%%

Nominal_voltage_LI = Simulink.Parameter
Nominal_voltage_LI.RTWInfo.StorageClass = 'SimulinkGlobal';
Nominal_voltage_LI=48;


SOC_INI_LI = Simulink.Parameter
SOC_INI_LI.RTWInfo.StorageClass = 'SimulinkGlobal';
SOC_INI_LI=50;% state of charge

Rated_capacity_LI = Simulink.Parameter
Rated_capacity_LI.RTWInfo.StorageClass = 'SimulinkGlobal';
Rated_capacity_LI=100;% Ah at C10


%% HYDROGEN TANK%%

H2ini = Simulink.Parameter
H2ini.RTWInfo.StorageClass = 'SimulinkGlobal';
H2ini=5.5;% kg of H2

tank_capacity = Simulink.Parameter
tank_capacity.RTWInfo.StorageClass = 'SimulinkGlobal';
tank_capacity=11; %kg of H2

